import React from 'react';

const NamesList = ({ names, onRemoveName }) => {
  return (
    <div className="max-w-md mx-auto mt-6 p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-xl font-bold mb-4">Nombres para Certificados</h2>
      {names.length === 0 ? (
        <p className="text-gray-500">No hay nombres agregados</p>
      ) : (
        <ul className="space-y-2">
          {names.map((name, index) => (
            <li 
              key={index} 
              className="flex justify-between items-center bg-gray-100 p-3 rounded-lg"
            >
              <span>{name}</span>
              <button 
                onClick={() => onRemoveName(index)}
                className="text-red-500 hover:text-red-700"
              >
                Eliminar
              </button>
            </li>
          ))}
        </ul>
      )}
      {names.length > 0 && (
        <div className="mt-4 text-center">
          <p className="text-gray-600">Total de certificados: {names.length}</p>
        </div>
      )}
    </div>
  );
};

export default NamesList;