import React, { useState } from 'react';

const PDFGenerator = ({ 
  templateImage, 
  names, 
  nameConfig 
}) => {
  const [error, setError] = useState(null);

  const generateCertificates = () => {
    if (!templateImage) {
      setError('No se ha cargado una plantilla de certificado');
      return;
    }

    names.forEach((name, index) => {
      // Crear canvas para cada certificado
      const canvas = document.createElement('canvas');
      canvas.width = 1190; // Ancho A4 landscape
      canvas.height = 842; // Alto A4 landscape
      const ctx = canvas.getContext('2d');

      // Cargar imagen de fondo
      const backgroundImage = new Image();
      backgroundImage.crossOrigin = 'Anonymous';
      
      backgroundImage.onload = () => {
        // Dibujar imagen de fondo
        ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);

        // Configurar estilo de texto
        ctx.font = `${nameConfig.fontSize}px Arial`;
        ctx.fillStyle = nameConfig.fontColor;
        
        // Calcular posición precisa
        const x = canvas.width * (nameConfig.position.x / 100);
        const y = canvas.height * (nameConfig.position.y / 100);

        // Guardar estado del contexto
        ctx.save();
        
        // Mover al punto de rotación
        ctx.translate(x, y);
        
        // Rotar
        ctx.rotate(nameConfig.rotation * Math.PI / 180);

        // Medir el texto para centrar
        const textMetrics = ctx.measureText(name);
        const textWidth = textMetrics.width;
        const textHeight = nameConfig.fontSize;

        // Dibujar nombre centrado en el punto de referencia
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(name, 0, 0);

        // Restaurar contexto
        ctx.restore();

        // Crear enlace de descarga
        const link = document.createElement('a');
        link.download = `Certificado_${name.replace(/\s+/g, '_')}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      };

      backgroundImage.onerror = () => {
        setError(`Error al cargar la imagen para ${name}`);
      };

      backgroundImage.src = templateImage;
    });
  };

  return (
    <div className="max-w-md mx-auto mt-6">
      <button 
        onClick={generateCertificates}
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition text-lg font-semibold"
      >
        Generar Certificados
      </button>

      {error && (
        <div className="mt-4 bg-red-100 text-red-800 p-3 rounded-lg">
          {error}
        </div>
      )}
    </div>
  );
};

export default PDFGenerator;

// DONE