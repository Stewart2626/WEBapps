import React from 'react';

const CertificateList = ({ certificates }) => {
  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Certificados Generados</h2>
      {certificates.length === 0 ? (
        <p className="text-gray-500">No se han generado certificados aún</p>
      ) : (
        <ul className="space-y-2">
          {certificates.map((cert, index) => (
            <li 
              key={index} 
              className="flex justify-between items-center bg-gray-100 p-3 rounded-lg"
            >
              <span>{cert.fullName} - {cert.course}</span>
              <button className="text-blue-600 hover:underline">
                Ver Certificado
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default CertificateList;