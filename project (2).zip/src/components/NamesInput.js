import React, { useState } from 'react';

const NamesInput = ({ onNamesSubmit }) => {
  const [namesInput, setNamesInput] = useState('');
  const [inputMode, setInputMode] = useState('paste'); // 'paste' or 'manual'

  const handleSubmit = () => {
    // Procesar nombres, eliminando líneas vacías y espacios extra
    const names = namesInput
      .split('\n')
      .map(name => name.trim())
      .filter(name => name !== '');
    
    onNamesSubmit(names);
  };

  return (
    <div className="max-w-md mx-auto mt-6 p-6 bg-white rounded-xl shadow-lg">
      <div className="flex justify-center mb-4 space-x-4">
        <button 
          onClick={() => setInputMode('paste')}
          className={`px-4 py-2 rounded-lg transition ${
            inputMode === 'paste' 
              ? 'bg-black text-white' 
              : 'bg-gray-200 text-black hover:bg-gray-300'
          }`}
        >
          Pegar Lista
        </button>
        <button 
          onClick={() => setInputMode('manual')}
          className={`px-4 py-2 rounded-lg transition ${
            inputMode === 'manual' 
              ? 'bg-black text-white' 
              : 'bg-gray-200 text-black hover:bg-gray-300'
          }`}
        >
          Escribir Nombres
        </button>
      </div>

      <textarea 
        rows={inputMode === 'paste' ? 6 : 2}
        placeholder={
          inputMode === 'paste' 
            ? 'Pega aquí tu lista de nombres (uno por línea)' 
            : 'Escribe nombres separados por enter'
        }
        value={namesInput}
        onChange={(e) => setNamesInput(e.target.value)}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
      />

      <button 
        onClick={handleSubmit}
        disabled={!namesInput.trim()}
        className="w-full mt-4 bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition disabled:opacity-50"
      >
        {inputMode === 'paste' ? 'Procesar Lista' : 'Agregar Nombres'}
      </button>
    </div>
  );
};

export default NamesInput;