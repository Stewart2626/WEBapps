import React from 'react';

const CertificateDownloader = ({ 
  templateImage, 
  names, 
  nameConfig 
}) => {
  const generateCertificates = () => {
    names.forEach((name) => {
      const canvas = document.createElement('canvas');
      canvas.width = 1190;
      canvas.height = 842;
      const ctx = canvas.getContext('2d');

      const backgroundImage = new Image();
      backgroundImage.crossOrigin = 'Anonymous';
      
      backgroundImage.onload = () => {
        // Dibujar imagen de fondo
        ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);

        // Configurar estilo de texto
        ctx.font = `${nameConfig.fontSize}px Arial`;
        ctx.fillStyle = nameConfig.fontColor;
        
        // Calcular posición
        const x = canvas.width * (nameConfig.position.x / 100);
        const y = canvas.height * (nameConfig.position.y / 100);

        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(nameConfig.rotation * Math.PI / 180);

        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(name, 0, 0);

        ctx.restore();

        // Crear enlace de descarga
        const link = document.createElement('a');
        link.download = `Certificado_${name.replace(/\s+/g, '_')}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      };

      backgroundImage.src = templateImage;
    });
  };

  return (
    <button 
      onClick={generateCertificates}
      className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition text-lg font-semibold"
    >
      Generar Certificados
    </button>
  );
};

export default CertificateDownloader;

// DONE