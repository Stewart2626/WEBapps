import React from 'react';

const Header = () => {
  return (
    <header className="w-full bg-black text-white py-4 px-6 flex justify-between items-center">
      <h1 className="text-2xl font-bold">CertificaFácil Bulk</h1>
      <nav>
        <button className="bg-white text-black px-4 py-2 rounded-lg hover:bg-gray-200 transition">
          Nuevo Lote
        </button>
      </nav>
    </header>
  );
};

export default Header;