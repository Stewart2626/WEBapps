import React from 'react';

const Unknown = () => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md text-center">
      <h2 className="text-xl font-semibold mb-4">Componente Desconocido</h2>
      <p className="text-gray-600">
        Este componente aún no ha sido definido específicamente.
      </p>
    </div>
  );
};

export default Unknown;

// DONE