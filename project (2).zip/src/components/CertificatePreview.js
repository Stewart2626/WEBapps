import React from 'react';

const CertificatePreview = ({ certificateData }) => {
  if (!certificateData) return null;

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold mb-4 text-center">Vista Previa del Certificado</h2>
      <div className="border p-6 rounded-lg">
        <p><strong>Nombre:</strong> {certificateData.fullName}</p>
        <p><strong>Curso:</strong> {certificateData.course}</p>
        <p><strong>Horas:</strong> {certificateData.hours}</p>
      </div>
    </div>
  );
};

export default CertificatePreview;