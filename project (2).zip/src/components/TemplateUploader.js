import React, { useState } from 'react';

const TemplateUploader = ({ onTemplateUpload }) => {
  const [previewImage, setPreviewImage] = useState(null);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
        onTemplateUpload(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h2 className="text-xl font-semibold mb-4">Subir Plantilla de Certificado</h2>
      
      <input 
        type="file" 
        accept="image/*"
        onChange={handleFileUpload}
        className="w-full p-3 border border-gray-300 rounded-lg"
      />

      {previewImage && (
        <div className="mt-4">
          <h3 className="text-lg mb-2">Vista Previa</h3>
          <img 
            src={previewImage} 
            alt="Vista previa de la plantilla" 
            className="max-w-full h-auto rounded-lg shadow-md"
          />
        </div>
      )}
    </div>
  );
};

export default TemplateUploader;

// DONE