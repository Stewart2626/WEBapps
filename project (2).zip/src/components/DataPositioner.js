import React, { useState, useRef, useEffect } from 'react';

const DataPositioner = ({ templateImage, onPositionSet }) => {
  const [namePosition, setNamePosition] = useState({ x: 50, y: 50 });
  const [fontSize, setFontSize] = useState(24);
  const [fontColor, setFontColor] = useState('#000000');
  const [rotation, setRotation] = useState(0);
  const imageRef = useRef(null);

  const handlePositionChange = (axis, value) => {
    setNamePosition(prev => ({
      ...prev,
      [axis]: Number(value)
    }));
  };

  const handleSavePositions = () => {
    onPositionSet({
      position: namePosition,
      fontSize,
      fontColor,
      rotation
    });
  };

  return (
    <div className="max-w-2xl mx-auto mt-6 p-6 bg-white rounded-xl shadow-lg">
      <div className="relative">
        <img 
          ref={imageRef}
          src={templateImage} 
          alt="Plantilla de certificado" 
          className="w-full h-auto"
        />
        <div 
          className="absolute text-blue-500 font-bold"
          style={{
            left: `${namePosition.x}%`, 
            top: `${namePosition.y}%`,
            fontSize: `${fontSize}px`,
            color: fontColor,
            transform: `rotate(${rotation}deg)`,
            transformOrigin: 'center center'
          }}
        >
          Nombre Ejemplo
        </div>
      </div>

      <div className="mt-6 space-y-4">
        <div className="flex items-center space-x-4">
          <label className="font-semibold">Posición Horizontal:</label>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={namePosition.x}
            onChange={(e) => handlePositionChange('x', e.target.value)}
            className="w-full"
          />
          <span>{namePosition.x}%</span>
        </div>

        <div className="flex items-center space-x-4">
          <label className="font-semibold">Posición Vertical:</label>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={namePosition.y}
            onChange={(e) => handlePositionChange('y', e.target.value)}
            className="w-full"
          />
          <span>{namePosition.y}%</span>
        </div>

        <div className="flex items-center space-x-4">
          <label className="font-semibold">Tamaño de Fuente:</label>
          <input 
            type="range" 
            min="10" 
            max="72" 
            value={fontSize}
            onChange={(e) => setFontSize(Number(e.target.value))}
            className="w-full"
          />
          <span>{fontSize}px</span>
        </div>

        <div className="flex items-center space-x-4">
          <label className="font-semibold">Rotación:</label>
          <input 
            type="range" 
            min="-45" 
            max="45" 
            value={rotation}
            onChange={(e) => setRotation(Number(e.target.value))}
            className="w-full"
          />
          <span>{rotation}°</span>
        </div>

        <div className="flex items-center space-x-4">
          <label className="font-semibold">Color de Texto:</label>
          <input 
            type="color" 
            value={fontColor}
            onChange={(e) => setFontColor(e.target.value)}
            className="w-12 h-12 rounded-full"
          />
        </div>
        
        <button 
          onClick={handleSavePositions}
          className="w-full bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition"
        >
          Guardar Configuración de Nombre
        </button>
      </div>
    </div>
  );
};

export default DataPositioner;