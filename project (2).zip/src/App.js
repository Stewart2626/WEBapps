import React, { useState } from 'react';
import Header from './components/Header';
import TemplateUploader from './components/TemplateUploader';
import DataPositioner from './components/DataPositioner';
import NamesInput from './components/NamesInput';
import NamesList from './components/NamesList';
import PDFGenerator from './components/PDFGenerator';

function App() {
  const [templateImage, setTemplateImage] = useState(null);
  const [nameConfig, setNameConfig] = useState(null);
  const [names, setNames] = useState([]);

  const handleTemplateUpload = (image) => {
    setTemplateImage(image);
  };

  const handleNameConfigSet = (config) => {
    setNameConfig(config);
  };

  const handleNamesSubmit = (newNames) => {
    const uniqueNames = [...new Set([...names, ...newNames])];
    setNames(uniqueNames);
  };

  const handleRemoveName = (indexToRemove) => {
    setNames(names.filter((_, index) => index !== indexToRemove));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="container mx-auto px-4 py-8 space-y-6">
        <TemplateUploader onTemplateUpload={handleTemplateUpload} />
        
        {templateImage && (
          <DataPositioner 
            templateImage={templateImage} 
            onPositionSet={handleNameConfigSet} 
          />
        )}
        
        {nameConfig && (
          <>
            <NamesInput onNamesSubmit={handleNamesSubmit} />
            
            <NamesList 
              names={names} 
              onRemoveName={handleRemoveName} 
            />

            {names.length > 0 && (
              <PDFGenerator 
                templateImage={templateImage}
                names={names}
                nameConfig={nameConfig}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;

// DONE